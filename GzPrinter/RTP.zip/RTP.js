﻿(function () {
    var defaults = {
        rtp_template:'.rtp-template',
        rtp_header: ".rtp-header",
        rtp_footer: ".rtp-footer",
        rtp_item: '.rtp-item',
        font: {
            name:'Verdana, Geneva, sans-serif',
            size: '12pt'
        },
        printer: {
            name:'',
            pageWidth: 210,   //单位mm
            pageHeight: 297,
            dpi:96,  //打印机分辨率
            landscape: false,
            copies:1
        },
        margins: {
            top: 40,  //px
            bottom: 40,
            left: 40,
            right:40
        },
        usePager:true,
        pagerNumStyle: "第#p页/共#P页",
        preview:false
    };

    var settings = {};//global settings
    var $template = null;
    var $trs = null;
    var $header = null;
    var $footer = null;
    var $item = null;
    var currentPage = 0;//当前页

    function init(options) {
        $.extend(true, settings, defaults, options || {});
        $template = $(settings.rtp_template);

        currentPage = 0;
        pageCount = 0;
    }

    function print(callback) {
        //自动分页
        autoPage();

        var arr = [];
        $('.rtp-print-page-wrap .rtp-print-page').each(function () {
            arr.push($(this).get(0).outerHTML);
        });
        var data = {
            printerName: settings.printer.name,
            copies: settings.printer.copies,
            landscape: settings.printer.landscape,
            html: JSON.stringify(arr),
            preview: settings.preview
        };

        $.ajax({
            type: 'POST',
            url: 'http://localhost:12333/print',
            dataType: 'json',
            contentType: 'application/json',
            processData: false,
            data: JSON.stringify(data),
            success: function (rsp) {
                console.log(rsp);
                callback && callback(rsp);
            },
            error: function (ex) {
                callback && callback({ error: ex });
            }
        });
    }

    function autoPage() {
        //准备好打印容器
        var $rtpPrintContent = $('.rtp-print-content');
        if (!$rtpPrintContent.length) {
            $rtpPrintContent = $('<div class="rtp-print-content"><div class="rtp-print-page rtp-tpl"><div class="rtp-print-inner"></div></div><div class="rtp-print-page-wrap"></div></div>')
            $rtpPrintContent.appendTo('body');
        }
        var $pageWrap = $rtpPrintContent.find('.rtp-print-page-wrap');
        $pageWrap.html('');
        var pageWidthPx = convertMM2Px(settings.printer.pageWidth, settings.printer.dpi);
        var pageHeightPx = convertMM2Px(settings.printer.pageHeight, settings.printer.dpi);
        var fontRem = (settings.printer.dpi / 96).toFixed(2)+'rem';
        $rtpPrintContent.find('.rtp-print-page').css({
            "font-family": settings.font.name,
            "font-size": settings.font.size,
            "width": (settings.printer.landscape ? pageHeightPx : pageWidthPx)+"px",
            //"height": (settings.printer.landscape ? pageWidthPx : pageHeightPx) + "px"
        });
        $rtpPrintContent.find('.rtp-print-inner').css({
            "margin-left": settings.margins.left + "px",
            "margin-top": settings.margins.top + "px",
            "margin-right": settings.margins.right + "px",
            "margin-bottom": settings.margins.bottom + "px",
            "font-size": fontRem,
        });

        //将要打印的内容复制一份到容器中，从而测量高度
        var $tpl = $rtpPrintContent.find('.rtp-tpl .rtp-print-inner');
        $tpl.html($template.clone());
        //添加一个pager用于测量pager高度
        var pagerHeight = 0;
        if (settings.usePager) {
            var $pagerTest = $('<div class="rtp-print-pager" style="text-align:right;"></div>');
            $pagerTest.html(getPageStyle(1, 1));
            $tpl.append($pagerTest);
            pagerHeight = $pagerTest.outerHeight(true);
        }

        $header = $tpl.find(settings.rtp_header);
        $footer = $tpl.find(settings.rtp_footer);
        $item = $tpl.find(settings.rtp_item);
        $trs = $item.find('tbody tr');

        var contentHeight = 0;
        if (settings.printer.landscape) {
            contentHeight = pageWidthPx - settings.margins.top - settings.margins.bottom;
        } else {
            contentHeight = pageHeightPx - settings.margins.top - settings.margins.bottom;
        }

        var headHeight = $header.outerHeight(true);
        var $thead = $item.find('thead');
        var theadHeight = 0;
        if ($thead.length) {
            theadHeight = $thead.outerHeight(true);
        }
        var footHeight = $footer.outerHeight(true);
        
        var firstTBodyHeight = contentHeight - headHeight - theadHeight - pagerHeight;
        var otherTBodyHeight = contentHeight - theadHeight - pagerHeight;

        var $table = $item.find('table');
        var $content = $table.clone().find("tbody").remove().end().removeAttr("id");

        var totalHeight = 0;
        var startLine = 0;
        var rowCount = $trs.length;
        if (rowCount > 0) {
            $trs.each(function (i) {
                var cHeight = $(this).outerHeight(true);
                $(this).height(cHeight);
                var h = currentPage == 0 ? firstTBodyHeight : otherTBodyHeight;
                if ((totalHeight + cHeight) < h) {
                    totalHeight += cHeight;
                    if (i == rowCount - 1) {
                        newPage(i + 1);
                    }
                } else {
                    console.log({ totalHeight, h, pagerHeight, theadHeight, contentHeight, headHeight,i });
                    newPage(i);
                    totalHeight += cHeight;  //将本行高度计算上，不然下一页高度少算了1行
                }
            });
        } else {
            newPage(0);
        }
        //更改页面中的pageCount
        $rtpPrintContent.find('.rtp-print-pager').each(function () {
            $(this).html($(this).html().replace(/#P/g, currentPage));
        });
        //清除掉复制过来的模板
        $tpl.html('');

        if (settings.usePager) {
            $rtpPrintContent.find('.rtp-print-page').css({
                "font-family": settings.font.name,
                "font-size": settings.font.size,
                "width": (settings.printer.landscape ? pageHeightPx : pageWidthPx) + "px",
                "height": (settings.printer.landscape ? pageWidthPx : pageHeightPx) + "px"
            });
        } else {
            $rtpPrintContent.find('.rtp-print-page').css({
                "font-family": settings.font.name,
                "font-size": settings.font.size,
                "width": (settings.printer.landscape ? pageHeightPx : pageWidthPx) + "px"
            });
        }
        
        $rtpPrintContent.find('.rtp-print-inner').css({
            "margin-left": settings.margins.left + "px",
            "margin-top": settings.margins.top + "px",
            "margin-right": settings.margins.right + "px",
            "margin-bottom": settings.margins.bottom + "px",
            "font-size": fontRem,
        });

        function newPage(index) {
            createPage(startLine, index);
            currentPage++;
            startLine = index;
            totalHeight = 0;
        }

        function createPage(startLine, offsetLine) {
            var $page = $('<div class="rtp-print-page"><div class="rtp-print-inner"></div></div>');
            var $inner = $page.find('.rtp-print-inner');
            $pageWrap.append($page);
            if (currentPage == 0) {
                $inner.append($header.clone());
            }
            if (startLine != offsetLine) {
                var $pageContent = $content.clone().append(getTrRecord(startLine, offsetLine));
                $inner.append($pageContent);
            }
            if (offsetLine == rowCount) {
                var leftHeight = contentHeight - (totalHeight + theadHeight);
                if (footHeight <= leftHeight) {
                    $inner.append($footer.clone());
                } else {
                    currentPage++;
                    totalHeight = 0;
                    theadHeight = 0;
                    createPage(offsetLine, offsetLine);
                }
            }
            if (settings.usePager) {
                var $pager = $('<div class="rtp-print-pager" style="text-align:right;"></div>');
                $pager.html(getPageStyle(currentPage + 1, 0));
                $inner.append($pager);
            }
            if (offsetLine != rowCount) {
                $inner.append(addPageBreak());
            }
        }

        //获取记录
        function getTrRecord(startLine, offsetLine) {
            return $trs.clone().slice(startLine, offsetLine);
        }
    }

    //获取分页样式
    function getPageStyle(currentPage, pageCount,settings) {
        var numStr = settings.pagerNumStyle;
        numStr = numStr.replace(/#p/g, currentPage);
        //numStr = numStr.replace(/#P/g, pageCount);
        return numStr;
    }

    //添加分页符
    function addPageBreak() {
        return "<div class='rtp-page-break' style='page-break-after:always;'></div>";
    }

    //将mm转换为像素
    function convertMM2Px(mm, dpi) {
        return Math.round(((mm*1.0 / 10) / 2.54) * dpi);
    }

    function RTP(options) {
        this.init(options);
    }

    RTP.prototype = {
        init: function (options) {
            var g = this;
            g.settings=$.extend(true, defaults, options || {});
        },
        print: function (callback) {
            var g = this;
            g.autoPage();
            var arr = [];
            $('.rtp-print-page-wrap .rtp-print-page').each(function () {
                arr.push($(this).get(0).outerHTML);
            });
            var data = {
                printer: g.settings.printer.name,
                copies: g.settings.printer.copies,
                landscape: g.settings.printer.landscape,
                html: JSON.stringify(arr),
                preview: g.settings.preview
            };
            $.ajax({
                type: 'POST',
                url: 'http://localhost:12333/print',
                dataType: 'json',
                contentType: 'application/json',
                processData: false,
                data: JSON.stringify(data),
                success: function (rsp) {
                    console.log(rsp);
                    callback && callback(rsp);
                },
                error: function (ex) {
                    callback && callback({ error: ex });
                }
            });
        },
        autoPage: function () {
            var g = this;
            var $template = $(g.settings.rtp_template);
            var $rtpPrintContent = $('.rtp-print-content');
            if (!$rtpPrintContent.length) {
                $rtpPrintContent = $('<div class="rtp-print-content"><div class="rtp-print-page rtp-tpl"><div class="rtp-print-inner"></div></div><div class="rtp-print-page-wrap"></div></div>')
                $rtpPrintContent.appendTo('body');
            }
            var $pageWrap = $rtpPrintContent.find('.rtp-print-page-wrap');
            $pageWrap.html('');
            var pageWidthPx = convertMM2Px(g.settings.printer.pageWidth, g.settings.printer.dpi);
            var pageHeightPx = convertMM2Px(g.settings.printer.pageHeight, g.settings.printer.dpi);
            var fontRem = (g.settings.printer.dpi / 96).toFixed(2) + 'rem';
            $rtpPrintContent.find('.rtp-print-page').css({
                "font-family": g.settings.font.name,
                "font-size": g.settings.font.size,
                "width": (g.settings.printer.landscape ? pageHeightPx : pageWidthPx) + "px",
                //"height": (settings.printer.landscape ? pageWidthPx : pageHeightPx) + "px"
            });
            $rtpPrintContent.find('.rtp-print-inner').css({
                "margin-left": g.settings.margins.left + "px",
                "margin-top": g.settings.margins.top + "px",
                "margin-right": g.settings.margins.right + "px",
                "margin-bottom": g.settings.margins.bottom + "px",
                "font-size": fontRem,
            });

            //将要打印的内容复制一份到容器中，从而测量高度
            var $tpl = $rtpPrintContent.find('.rtp-tpl .rtp-print-inner');
            $tpl.html($template.clone());
            //添加一个pager用于测量pager高度
            var pagerHeight = 0;
            if (g.settings.usePager) {
                var $pagerTest = $('<div class="rtp-print-pager" style="text-align:right;"></div>');
                $pagerTest.html(getPageStyle(1, 1, g.settings));
                $tpl.append($pagerTest);
                pagerHeight = $pagerTest.outerHeight(true);
            }

            var $header = $tpl.find(g.settings.rtp_header);
            var $footer = $tpl.find(g.settings.rtp_footer);
            var $item = $tpl.find(g.settings.rtp_item);
            var $trs = $item.find('tbody tr');

            var contentHeight = 0;
            if (g.settings.printer.landscape) {
                contentHeight = pageWidthPx - g.settings.margins.top - g.settings.margins.bottom;
            } else {
                contentHeight = pageHeightPx - g.settings.margins.top - g.settings.margins.bottom;
            }

            var headHeight = $header.outerHeight(true);
            var $thead = $item.find('thead');
            var theadHeight = 0;
            if ($thead.length) {
                theadHeight = $thead.outerHeight(true);
            }
            var footHeight = $footer.outerHeight(true);

            var firstTBodyHeight = contentHeight - headHeight - theadHeight - pagerHeight;
            var otherTBodyHeight = contentHeight - theadHeight - pagerHeight;

            var $table = $item.find('table');
            var $content = $table.clone().find("tbody").remove().end().removeAttr("id");

            var totalHeight = 0;
            var startLine = 0;
            var currentPage = 0;
            var rowCount = $trs.length;
            if (rowCount > 0) {
                $trs.each(function (i) {
                    var cHeight = $(this).outerHeight(true);
                    $(this).height(cHeight);
                    var h = currentPage == 0 ? firstTBodyHeight : otherTBodyHeight;
                    if ((totalHeight + cHeight) < h) {
                        totalHeight += cHeight;
                        if (i == rowCount - 1) {
                            newPage(i + 1);
                        }
                    } else {
                        //console.log({ totalHeight, h, pagerHeight, theadHeight, contentHeight, headHeight, i });
                        newPage(i);
                        totalHeight += cHeight;  //将本行高度计算上，不然下一页高度少算了1行
                    }
                });
            } else {
                newPage(0);
            }
            //更改页面中的pageCount
            $rtpPrintContent.find('.rtp-print-pager').each(function () {
                $(this).html($(this).html().replace(/#P/g, currentPage));
            });
            //清除掉复制过来的模板
            $tpl.html('');

            if (g.settings.usePager) {
                $rtpPrintContent.find('.rtp-print-page').css({
                    "font-family": g.settings.font.name,
                    "font-size": g.settings.font.size,
                    "width": (g.settings.printer.landscape ? pageHeightPx : pageWidthPx) + "px",
                    "height": (g.settings.printer.landscape ? pageWidthPx : pageHeightPx) + "px"
                });
            } else {
                $rtpPrintContent.find('.rtp-print-page').css({
                    "font-family": g.settings.font.name,
                    "font-size": g.settings.font.size,
                    "width": (g.settings.printer.landscape ? pageHeightPx : pageWidthPx) + "px"
                });
            }

            $rtpPrintContent.find('.rtp-print-inner').css({
                "margin-left": g.settings.margins.left + "px",
                "margin-top": g.settings.margins.top + "px",
                "margin-right": g.settings.margins.right + "px",
                "margin-bottom": g.settings.margins.bottom + "px",
                "font-size": fontRem,
            });

            function newPage(index) {
                createPage(startLine, index);
                currentPage++;
                startLine = index;
                totalHeight = 0;
            }

            function createPage(startLine, offsetLine) {
                var $page = $('<div class="rtp-print-page"><div class="rtp-print-inner"></div></div>');
                var $inner = $page.find('.rtp-print-inner');
                $pageWrap.append($page);
                if (currentPage == 0) {
                    $inner.append($header.clone());
                }
                if (startLine != offsetLine) {
                    var $pageContent = $content.clone().append(getTrRecord(startLine, offsetLine));
                    $inner.append($pageContent);
                }
                if (offsetLine == rowCount) {
                    var leftHeight = contentHeight - (totalHeight + theadHeight);
                    if (footHeight <= leftHeight) {
                        $inner.append($footer.clone());
                    } else {
                        currentPage++;
                        totalHeight = 0;
                        theadHeight = 0;
                        createPage(offsetLine, offsetLine);
                    }
                }
                if (g.settings.usePager) {
                    var $pager = $('<div class="rtp-print-pager" style="text-align:right;"></div>');
                    $pager.html(getPageStyle(currentPage + 1, 0, g.settings));
                    $inner.append($pager);
                }
                if (offsetLine != rowCount) {
                    $inner.append(addPageBreak());
                }
            }

            //获取记录
            function getTrRecord(startLine, offsetLine) {
                return $trs.clone().slice(startLine, offsetLine);
            }
        }
    };

    window.getRTP = function (options) {
        return new RTP(options);
    };
})();